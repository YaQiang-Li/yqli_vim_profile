consolas-powerline-vim
======================

Fixed Consolas font for use with Vim Powerline. Font has all variants: regular, bold, italic, bold-italic.

## Usage

Extract the font files and install them onto your system. Choose to use those fonts in Vim.

For more information about the purpose of this, as well as usage information, please see:

[Consolas Font in Vim Powerline](http://codejury.com/consolas-font-in-vim-powerline-windows/)


